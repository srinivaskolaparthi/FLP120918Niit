package org.cap.boot;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.config.JavaConfig;
import org.cap.model.Book;
import org.cap.service.BookService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	
	private static final AtomicInteger bookId=new AtomicInteger();
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=
				new AnnotationConfigApplicationContext(JavaConfig.class);
		
		BookService bookService=(BookService)context.getBean("bookService");
		
		//bookService.createBookTable();
		
		//bookService.saveAll(getAllBooks());
		//bookService.delete(3);
		
		/*Book book=new Book();
		book.setBookId(2);
		book.setBookName("ABC Book");
		book.setAuthor("Zyon");
		book.setPrice(1500);*/
		
		//bookService.update(book);
		/*Book book=bookService.findBookById(7);
		System.out.println(book);*/
		
		List<Book> books=bookService.getAllBooks();
		for(Book book:books) {
			System.out.println(book);
		}
	}
	
	public static List<Book> getAllBooks(){
		List<Book> books=new ArrayList<>();
		books.add(new Book(bookId.getAndIncrement(), "java Complete Ref", "Robert", 1200));
		books.add(new Book(bookId.getAndIncrement(), "Oracle Ref", "Eric", 700));
		books.add(new Book(bookId.getAndIncrement(), "CSS Ref", "Jack", 3400));books.add(new Book(bookId.getAndIncrement(), "Oracle Ref", "Eric", 700));
		books.add(new Book(bookId.getAndIncrement(), "CPP Ref", "Thomson", 890));
		
		books.add(new Book(bookId.getAndIncrement(), "C Ref", "Ram", 1299));
		books.add(new Book(bookId.getAndIncrement(), "Spring Ref", "Charan", 700));
		books.add(new Book(bookId.getAndIncrement(), "PCF Ref", "Chandra", 6700));
		books.add(new Book(bookId.getAndIncrement(), "AWS Ref", "Clara", 700));
		books.add(new Book(bookId.getAndIncrement(), "HTMl Ref", "Silviya", 700));
		
		
		
		return books;
	}


}
