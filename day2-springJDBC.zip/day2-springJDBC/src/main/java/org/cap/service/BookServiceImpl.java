package org.cap.service;

import java.util.List;

import org.cap.dao.BookDao;
import org.cap.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("bookService")
public class BookServiceImpl implements BookService{
	
	@Autowired
	private BookDao bookDao;
	
	@Override
	public void createBookTable() {
		bookDao.createBookTable();
	}

	@Override
	public void saveAll(List<Book> books) {
		bookDao.saveAll(books);
	}

	@Override
	public void save(Book book) {
		bookDao.save(book);
	}

	@Override
	public void delete(int bookId) {
		bookDao.delete(bookId);
	}

	@Override
	public void update(Book book) {
		bookDao.update(book);
	}

	@Override
	public Book findBookById(int bookId) {
		
		return bookDao.findBookById(bookId);
	}

	@Override
	public List<Book> getAllBooks() {
		
		return bookDao.getAllBooks();
	}

}
