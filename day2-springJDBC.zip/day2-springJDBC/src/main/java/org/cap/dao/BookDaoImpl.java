package org.cap.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.cap.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("bookDao")
public class BookDaoImpl implements BookDao{
	
	
	@Autowired
	private JdbcTemplate jdbcTemp;

	@Override
	public void createBookTable() {
		String sql="create table book(bookid int primary key, bookName varchar(15),"
				+ "author varchar(20), price numeric(8,2))";
		jdbcTemp.execute(sql);
		//System.out.println("table created");
	}
	
	
	@Override
	public void saveAll(List<Book> books) {
		
		for(Book book:books) {
			save(book);
		}
	}

	@Override
	public void save(Book book) {
		
		String sql="insert into book values(?,?,?,?)";
		jdbcTemp.update(sql, book.getBookId(),book.getBookName(),
				book.getAuthor(),book.getPrice());
		System.out.println("Book " + book.getBookName() + " inserted!");
		
	}


	@Override
	public void delete(int bookId) {
		String sql="delete from book where bookId=?";
		jdbcTemp.update(sql,bookId);
		System.out.println("Book " + bookId + " deleted!");
		
	}


	@Override
	public void update(Book book) {
		String sql="update book set bookName=?,author=?,price=? where bookId=?";
		jdbcTemp.update(sql,new Object[] {book.getBookName(),book.getAuthor(),
				book.getPrice(),book.getBookId()});
		System.out.println("Book " + book.getBookId() + " updated!");
		
	}


	@Override
	public Book findBookById(int bookId) {
		String sql="select * from book where bookId=?";
		Book book=(Book)jdbcTemp.queryForObject(sql,new Object[] {bookId},
				new BeanPropertyRowMapper(Book.class));
		return book;
	}


	@Override
	public List<Book> getAllBooks() {
		String sql="select * from book";
		List<Book> books=jdbcTemp.query(sql, new BeanPropertyRowMapper<>(Book.class));
		return books;
	}
}
