package org.cap.dao;

import java.util.List;

import org.cap.model.Book;

public interface BookDao {

	public void createBookTable();
	
	public void saveAll(List<Book> books);
	
	public void save(Book book);
	
	public void delete(int bookId);
	
	public void update(Book book);
	
	public Book findBookById(int bookId);
	
	public List<Book> getAllBooks();
}
